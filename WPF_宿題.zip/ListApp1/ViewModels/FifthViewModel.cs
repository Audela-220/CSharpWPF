﻿// ---------------------------------------------------------------------
// <copyright file="FifthViewModel.cs" company="DMG MORI B.U.G. CO.,LTD.">
// Copyright (C) 2020 DMG MORI B.U.G. CO.,LTD. All rights reserved.
// </copyright>
// ---------------------------------------------------------------------

namespace ListApp1.ViewModels
{
	class FifthViewModel : CommonViewModel
	{
		public FifthViewModel() : base() { }
	}
}
