﻿// ---------------------------------------------------------------------
// <copyright file="SecondViewModel.cs" company="DMG MORI B.U.G. CO.,LTD.">
// Copyright (C) 2020 DMG MORI B.U.G. CO.,LTD. All rights reserved.
// </copyright>
// ---------------------------------------------------------------------

namespace ListApp1.ViewModels
{
	internal class SecondViewModel : CommonViewModel
	{
		public SecondViewModel() : base() { }
	}
}
