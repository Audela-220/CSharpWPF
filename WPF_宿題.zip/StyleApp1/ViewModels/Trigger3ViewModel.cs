﻿// ---------------------------------------------------------------------
// <copyright file="Trigger3ViewModel.cs" company="DMG MORI B.U.G. CO.,LTD.">
// Copyright (C) 2020 DMG MORI B.U.G. CO.,LTD. All rights reserved.
// </copyright>
// ---------------------------------------------------------------------

namespace StyleApp1.ViewModels
{
	internal class Trigger3ViewModel
	{
		// デザインのみだけなので、ViewModelは空です。
	}
}
