﻿// ---------------------------------------------------------------------
// <copyright file="Genger.cs" company="DMG MORI B.U.G. CO.,LTD.">
// Copyright (C) 2020 DMG MORI B.U.G. CO.,LTD. All rights reserved.
// </copyright>
// ---------------------------------------------------------------------

using System;

namespace ListApp1.Models
{
	internal enum Gender
	{
		Mail,		// 男性
		Female,		// 女性
		Unknown		// 未定
	}
}
