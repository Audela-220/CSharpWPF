﻿// ---------------------------------------------------------------------
// <copyright file="Trigger2ViewModel.cs" company="DMG MORI B.U.G. CO.,LTD.">
// Copyright (C) 2020 DMG MORI B.U.G. CO.,LTD. All rights reserved.
// </copyright>
// ---------------------------------------------------------------------

namespace StyleApp1.ViewModels
{
	internal class Trigger2ViewModel
	{
		// デザインのみだけなので、ViewModelは空です。
	}
}
