﻿// ---------------------------------------------------------------------
// <copyright file="Sample1ViewModel.cs" company="DMG MORI B.U.G. CO.,LTD.">
// Copyright (C) 2020 DMG MORI B.U.G. CO.,LTD. All rights reserved.
// </copyright>
// ---------------------------------------------------------------------
using System;

namespace StyleApp1.ViewModels
{
    class Sample1ViewModel
    {
		// デザインのみだけなので、ViewModelは空です。
	}
}
